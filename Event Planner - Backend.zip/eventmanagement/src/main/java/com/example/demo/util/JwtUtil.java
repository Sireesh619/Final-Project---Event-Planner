package com.example.demo.util;

import java.util.Base64;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtUtil {
	
	public String setToken(String pass, String uname) {
		return Jwts.builder()
				.setId("Puri")
				.setSubject(pass)
				.setIssuer("Purneet")
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(10 * 60 * 24)))
				.signWith(SignatureAlgorithm.HS256, Base64.getEncoder().encode(uname.getBytes()))
				.compact();
		
	}
	
	public Claims getClaims(String token, String key) {
		Claims c =  Jwts.parser()
				.setSigningKey(Base64.getEncoder().encode(key.getBytes()))
				.parseClaimsJws(token)
				.getBody();
		return c;
	}
	
	public Date getDate(String token, String secret) {
		Claims c = getClaims(token, secret);
		return c.getExpiration();
	}
	
	public String getUsername(String token, String secret) {
		return getClaims(token, secret).getSubject();
	}
	
	public boolean isValidToken(String key,String token) {
		//  expDte > curr dte
		return getClaims(key, token)
				.getExpiration()
				.after(new Date(System.currentTimeMillis()));
	}
}
