package com.example.demo.controller;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Admin;
import com.example.demo.model.Corporate;
import com.example.demo.model.Exhibition;
import com.example.demo.model.Feedback;
import com.example.demo.model.Social;
import com.example.demo.model.User;
import com.example.demo.repository.IAdmin;
import com.example.demo.repository.ICorporate;
import com.example.demo.repository.IExhibition;
import com.example.demo.repository.IFeedback;
import com.example.demo.repository.ISocial;
import com.example.demo.repository.IUser;
import com.example.demo.util.JwtUtil;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/events")
public class EventController{
	
	@Autowired
	ISocial social;
	@Autowired
	IExhibition exhibition;
	@Autowired
	ICorporate corporate;
	@Autowired
	IFeedback feedback;
	@Autowired
	IAdmin admin;
	@Autowired
	IUser user;
	@Autowired 
	JwtUtil util;
	
	@GetMapping("/social")
	public List<Social> getsocial(){
		return social.findAll();
	}
	
	@PostMapping("/social")
	public Social addparticipant(@RequestBody Social s) {
		return social.save(s);
	}
	
	@GetMapping("/social/{email}")
	public List<Social> getbyemail(@PathVariable String email){
		return social.findByemail(email);
	}
	
	@GetMapping("/exhibition")
	public List<Exhibition> getexhibition(){
		return exhibition.findAll();
	}
	
	@PostMapping("/exhibition")
	public Exhibition addparticipant(@RequestBody Exhibition e) {
		return exhibition.save(e);
	}
	
	@GetMapping("/exhibition/{email}")
	public List<Exhibition> getbymail(@PathVariable String email){
		return exhibition.findByemail(email);
	}
	
	@GetMapping("/corporate")
	public List<Corporate> getcorporate(){
		return corporate.findAll();
	}
	
	@PostMapping("/corporate")
	public Corporate addcorporate(@RequestBody Corporate c) {
		return corporate.save(c);
	}
	
	@GetMapping("/corporate/{email}")
	public List<Corporate> searchbymail(@PathVariable String email){
		return corporate.findByemail(email);
	}
	
	@GetMapping("/feedback")
	public List<Feedback> getfeedbacks() {
		return feedback.findAll();
	}
	
	@PostMapping("/feedback")
	public Feedback addfeedback(@RequestBody Feedback f) {
		return feedback.save(f);
	}
	
	@DeleteMapping("/feedback/{id}")
	public void deletefeedback(@PathVariable int id) {
		feedback.deleteById(id);
	}
	
	@GetMapping("/admin")
	public List<Admin> getAdmins(){
		return admin.findAll();
	}
	
	@PostMapping("/admin")
	public Admin addadmin(@RequestBody Admin a) {
		String password = a.getPassword();
		String token = util.setToken(password, a.getName());
		a.setPassword(token);
		return admin.save(a);
	}
	
	@GetMapping("/user")
	public List<User> getUsers(){
		return user.findAll();
	}
	
	@PostMapping("/user")
	public User addUser(@RequestBody User u) {
		String password = u.getPassword();
		String token = util.setToken(password, u.getEmail());
		u.setPassword(token);
		return user.save(u);
	}
	
}
