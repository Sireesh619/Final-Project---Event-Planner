package com.example.demo.controller;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Admin;
import com.example.demo.model.User;
import com.example.demo.repository.IAdmin;
import com.example.demo.repository.IUser;
import com.example.demo.util.JwtUtil;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/events")
public class LoginController {
	
	@Autowired
	JwtUtil util;
	@Autowired
	IAdmin admin;
	@Autowired
	IUser user;
	
	@PostMapping("/login/admin")
	public boolean checkAdminValidity(@RequestBody Admin a) {
		List<Admin> alist = admin.findByname(a.getName());
		if(alist.isEmpty())
			return false;
		
		Iterator<Admin> it = alist.iterator();
		Admin ad;
		while(it.hasNext()) {
			ad = it.next();
			System.out.println(a.getPassword());
			System.out.println(ad.getPassword());
			System.out.println(util.getUsername(ad.getPassword(), ad.getName()));
			if((util.isValidToken(ad.getPassword(), ad.getName())) && (a.getPassword().equals(util.getUsername(ad.getPassword(), ad.getName())))){
				return true;
			}
		}
		return false;
	}
	
	@PostMapping("/login/user")
	public boolean checkUserValidity(@RequestBody User u) {
		List<User> ulist = user.findByEmail(u.getEmail());
		if(ulist.isEmpty())
			return false;
		
		Iterator<User> it = ulist.iterator();
		User usr;
		while(it.hasNext()) {
			usr = it.next();
			String usrtoken = usr.getPassword();
			System.out.println(u.getPassword());
			System.out.println(usrtoken);
			if((util.isValidToken(usrtoken, u.getEmail()) && (u.getPassword().equals(util.getUsername(usrtoken, u.getEmail()))))){
				return true;
			}
		}
		return false;
	}
	

}
