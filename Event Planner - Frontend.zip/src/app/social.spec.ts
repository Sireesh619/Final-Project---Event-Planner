import { Social } from './social';

describe('Social', () => {
  it('should create an instance', () => {
    expect(new Social()).toBeTruthy();
  });
});
