import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorporateeventComponent } from './corporateevent.component';

describe('CorporateeventComponent', () => {
  let component: CorporateeventComponent;
  let fixture: ComponentFixture<CorporateeventComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorporateeventComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CorporateeventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
