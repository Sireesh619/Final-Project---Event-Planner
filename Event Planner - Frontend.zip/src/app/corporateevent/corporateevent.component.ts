import { Component, OnInit } from '@angular/core';
import { Corporate } from '../corporate';
import { ParticipantsService } from '../participants.service';

@Component({
  selector: 'app-corporateevent',
  templateUrl: './corporateevent.component.html',
  styleUrls: ['./corporateevent.component.css']
})
export class CorporateeventComponent implements OnInit {

  public corporate : Corporate = new Corporate();
  constructor(public participant : ParticipantsService) { }

  ngOnInit(): void {
  }

  public price: number;
  public date: string;

  public getPrice(){
    this.price = (this.corporate.choice == "Custom Event")?500:(this.corporate.choice == "Product Launch")?700:(this.corporate.choice == "Conference")?1500:(this.corporate.choice == "Virtual")?200:0;
  }

  public getDate(){
    this.date = (this.corporate.choice == "Custom Event")?"2/1/2023":(this.corporate.choice == "Product Launch")?"9/1/2023":(this.corporate.choice == "Conference")?"20/1/2023":(this.corporate.choice == "Virtual")?"5/2/2023":"";
  }
  public expr:string = "";
  public isValid:boolean = false;
  public validate(): any {
    this.isValid = false;
    if((!this.corporate.firstName) || (!this.corporate.lastName))
      this.expr = "Enter full name";
    else
      if(this.corporate.email.length == 0)
        this.expr = "Enter email";
      else
        if((this.corporate.email.indexOf("@") == -1) || (this.corporate.email.indexOf(".") == -1))
          this.expr = "Invalid email";
        else
          if((this.corporate.phone / 1000000000 < 1) || (this.corporate.phone / 1000000000 >= 10))
            this.expr = "Phone should be 10 digits";
          else
            if(!this.corporate.choice)
              this.expr = "Choose an event";
            else {
              this.isValid = true;
              this.assign();
              this.expr = "Registration Successful";
            }  
    }

    public assign() {
      this.participant.saveCorporate(this.corporate)
      .subscribe(data => {
        this.corporate = data;
      }, error => {
        console.log(error);
      });
  }

}
