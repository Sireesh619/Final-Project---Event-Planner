import { Component, OnInit } from '@angular/core';
import { ParticipantsService } from '../participants.service';
import { Social } from '../social';

@Component({
  selector: 'app-socialevent',
  templateUrl: './socialevent.component.html',
  styleUrls: ['./socialevent.component.css']
})
export class SocialeventComponent implements OnInit {

  public social : Social = new Social();
  constructor(public participant : ParticipantsService) { }

  ngOnInit(): void {
  }

  public price: number;
  public date: string;

  public getPrice(){
    this.price = (this.social.choice == "Concerts")?600:(this.social.choice == "Birthday Party")?800:(this.social.choice == "Wedding")?1000:(this.social.choice == "Virtual")?200:0;
  }

  public getDate(){
    this.date = (this.social.choice == "Concerts")?"7/2/2023":(this.social.choice == "Birthday Party")?"29/1/2023":(this.social.choice == "Wedding")?"30/2/2023":(this.social.choice == "Virtual")?"15/1/2023":"";
  }
  public expr:string = "";
  public isValid:boolean = false;
  public validate(): any {
    this.isValid = false;
    if((!this.social.firstName) || (!this.social.lastName))
      this.expr = "Enter full name";
    else
      if(!this.social.email)
        this.expr = "Enter email";
      else
        if((this.social.email.indexOf("@") == -1) || (this.social.email.indexOf(".") == -1))
          this.expr = "Invalid email";
        else
          if((this.social.phone / 1000000000 < 1) || (this.social.phone / 1000000000 >= 10))
            this.expr = "Phone should be 10 digits";
          else
            if(!this.social.choice)
              this.expr = "Choose an event";
            else {
              this.isValid = true;
              this.assign();
              this.expr = "Registration Successful";
            }  
    }

    public assign() {
      this.participant.saveSocial(this.social)
      .subscribe(data => {
        this.social = data;
      }, error => {
        console.log(error);
      });
  }

}
