import { Exhibition } from './exhibition';

describe('Exhibition', () => {
  it('should create an instance', () => {
    expect(new Exhibition()).toBeTruthy();
  });
});
