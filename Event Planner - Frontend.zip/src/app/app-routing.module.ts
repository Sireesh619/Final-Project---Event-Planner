import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { GalleryComponent } from './gallery/gallery.component';
import { EventComponent } from './event/event.component';
import { ContactComponent } from './contact/contact.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { CorporateeventComponent } from './corporateevent/corporateevent.component';
import { ExhibitioneventComponent } from './exhibitionevent/exhibitionevent.component';
import { SocialeventComponent } from './socialevent/socialevent.component';
import { AdminoptionsComponent } from './adminoptions/adminoptions.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ViewbookingsComponent } from './viewbookings/viewbookings.component';
import { ViewfeedbacksComponent } from './viewfeedbacks/viewfeedbacks.component';
import { CreateadminComponent } from './createadmin/createadmin.component';
import { CreateuserComponent } from './createuser/createuser.component';
import { ViewuserbookingComponent } from './viewuserbooking/viewuserbooking.component';

const routes: Routes = [
    {path: 'home', component: HomeComponent},
    {path: 'login', component: LoginComponent},
    {path: 'gallery', component: GalleryComponent},
    {path: 'event', component: EventComponent},
    {path: 'about-us', component: AboutUsComponent},
    {path: 'contact', component: ContactComponent},
    {path: 'corporateevent', component: CorporateeventComponent},
    {path: 'exhibitionevent', component: ExhibitioneventComponent},
    {path: 'socialevent', component: SocialeventComponent},
    {path: 'options', component: AdminoptionsComponent},
    {path: 'admin', component: AdminloginComponent},
    {path: 'viewbookings', component: ViewbookingsComponent},
    {path: 'viewfeedbacks', component: ViewfeedbacksComponent},
    {path: 'create-admin', component: CreateadminComponent},
    {path: 'create-user', component: CreateuserComponent},
    {path: 'view-bookings/:email', component: ViewuserbookingComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
