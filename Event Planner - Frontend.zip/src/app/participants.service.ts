import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Social } from './social';
import { Exhibition } from './exhibition';
import { Corporate } from './corporate';
import { Feedback } from './feedback';
import { Admins } from './admins';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class ParticipantsService {

  constructor(private http:HttpClient) { }
  private baseURL = "http://localhost:8090/events";

  public getSocialList() : Observable<Social[]> {
    return this.http.get<Social[]>(`${this.baseURL}/social`);
  }
  
  public saveSocial(social: Social): Observable<any>{
    return this.http.post(`${this.baseURL}/social`, social);
  }

  public getSocialbyemail(email: String) : Observable<Social[]>{
    return this.http.get<Social[]>(`${this.baseURL}/social/${email}`);
  }

  public getExhibitionList(): Observable<Exhibition[]> {
    return this.http.get<Exhibition[]>(`${this.baseURL}/exhibition`);
  }

  public saveExhibition(exhibition: Exhibition): Observable<any>{
    return this.http.post(`${this.baseURL}/exhibition`, exhibition);
  }

  public getExhibitionbyemail(email: String) : Observable<Exhibition[]>{
    return this.http.get<Exhibition[]>(`${this.baseURL}/exhibition/${email}`);
  }
  public getCorporateList(): Observable<Corporate[]>{
    return this.http.get<Corporate[]>(`${this.baseURL}/corporate`);
  }

  public saveCorporate(corporate : Corporate): Observable<any>{
    return this.http.post(`${this.baseURL}/corporate`, corporate);
  }

  public getCorporatebyemail(email: String) : Observable<Corporate[]>{
    return this.http.get<Corporate[]>(`${this.baseURL}/corporate/${email}`);
  }

  public getFeedbackList(): Observable<Feedback[]>{
    return this.http.get<Feedback[]>(`${this.baseURL}/feedback`);
  }

  public saveFeedback(feedback: Feedback) : Observable<any>{
    return this.http.post(`${this.baseURL}/feedback`, feedback);
  }

  public deleteFeedback(id: number): Observable<any>{
    return this.http.delete(`${this.baseURL}/feedback/${id}`);
  }

  public getAdmins(): Observable<Admins[]>{
    return this.http.get<Admins[]>(`${this.baseURL}/admin`);
  }

  public createAdmin(admin : Admins): Observable<any>{
    return this.http.post(`${this.baseURL}/admin`, admin);
  }

  public adminLogin(admin: Admins): Observable<any>{
    return this.http.post(`${this.baseURL}/login/admin`, admin);
  }

  public getUsers(): Observable<User[]>{
    return this.http.get<User[]>(`${this.baseURL}/user`);
  }

  public createUser(user: User): Observable<any>{
    return this.http.post(`${this.baseURL}/user`, user);
  }

  public userLogin(user: User): Observable<any>{
    return this.http.post(`${this.baseURL}/login/user`, user);
  }

} 
