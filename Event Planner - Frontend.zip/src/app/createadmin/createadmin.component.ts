import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admins } from '../admins';
import { ParticipantsService } from '../participants.service';

@Component({
  selector: 'app-createadmin',
  templateUrl: './createadmin.component.html',
  styleUrls: ['./createadmin.component.css']
})
export class CreateadminComponent implements OnInit {

  public admin: Admins = new Admins();

  constructor(private participant: ParticipantsService, private router: Router) { }

  ngOnInit(): void {
  }

  public addAdmin(){
    this.participant.createAdmin(this.admin).subscribe( data => {
      this.admin = data;
      this.router.navigate(['options']);
    }, error => {
      console.log(error);
    })
  }

  
}

  