import { Admins } from './admins';

describe('Admins', () => {
  it('should create an instance', () => {
    expect(new Admins()).toBeTruthy();
  });
});
