import { Component, OnInit } from '@angular/core';
import { ParticipantsService } from '../participants.service';
import { Admins } from '../admins';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  public admin: Admins = new Admins();

  constructor(private participant: ParticipantsService, private router: Router) { }

  
  ngOnInit(): void {
  }

  public login(){
    this.participant.adminLogin(this.admin).subscribe( data => {
      if(data)
        this.router.navigate(['options']);
      else
        this.router.navigate(['home']);
    }, error => console.log(error)
    )
  }

}
