import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  slides: any[] = new Array(3).fill({id: -1, src: '', title: '', subtitle: ''});
  constructor() { }

  ngOnInit(): void {
    this.slides[0] = {
      src: 'assets/10.png',
    };
    this.slides[1] = {
      src: 'assets/11.png',
    }
    this.slides[2] = {
      src: 'assets/111.png',
    }
  }
  onItemChange($event: any): void {
    console.log('Carousel onItemChange', $event);
  }

}