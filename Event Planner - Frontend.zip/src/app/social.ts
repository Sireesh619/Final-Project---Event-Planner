export class Social {
    id: number;
    firstName: string;
    lastName: string;
    phone: number;
    email: string;
    choice: string;
    requirements : string;
}
