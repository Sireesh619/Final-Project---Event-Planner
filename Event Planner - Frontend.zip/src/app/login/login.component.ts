import { Component, OnInit } from '@angular/core';
import { ParticipantsService } from '../participants.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  public user: User = new User();

  constructor(private participant: ParticipantsService, private router: Router) { }

  ngOnInit(): void {
  }

  public login(){
    this.participant.userLogin(this.user).subscribe( data => {
      if(data)
        this.router.navigate(['view-bookings', this.user.email]);
      else
        this.router.navigate(['home']);
      console.log(this.user);
    }, error => {
      console.log(error);
    })
  }

}

