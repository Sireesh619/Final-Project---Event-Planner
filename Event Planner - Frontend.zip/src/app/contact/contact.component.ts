import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { ParticipantsService } from '../participants.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  public feedback: Feedback = new Feedback();
  constructor(private participant: ParticipantsService) { }

  ngOnInit(): void {
  }
  public isValid: boolean = false;
  public expr:string;
  public validate(): any {
    this.isValid = false;
    if((!this.feedback.firstName) || (!this.feedback.lastName))
      this.expr = "Enter full name";
    else
     if(!this.feedback.email)
      this.expr = "Enter email";
     else 
      if(this.feedback.email.indexOf(".") == -1)
        this.expr = "Invalid email";
      else
        if(this.feedback.email.indexOf("@") == -1)
          this.expr = "Invalid email";
        else
          if((this.feedback.phone / 1000000000 < 1) || (this.feedback.phone / 1000000000 >= 10))
            this.expr = "Phone should be 10 digits";
          else
            if(!this.feedback.feedback)
              this.expr = "Please provide feedback";
            else{
              this.isValid = true;
              this.assign();
              this.expr = "Registration Successful";
            }
  }

  public assign(){
    this.participant.saveFeedback(this.feedback).subscribe(
      data => {
        this.feedback = data;
      }, error => {
        console.log(error);
      }
    );
  }

}
