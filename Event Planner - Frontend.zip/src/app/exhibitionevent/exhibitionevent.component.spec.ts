import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExhibitioneventComponent } from './exhibitionevent.component';

describe('ExhibitioneventComponent', () => {
  let component: ExhibitioneventComponent;
  let fixture: ComponentFixture<ExhibitioneventComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExhibitioneventComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ExhibitioneventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
