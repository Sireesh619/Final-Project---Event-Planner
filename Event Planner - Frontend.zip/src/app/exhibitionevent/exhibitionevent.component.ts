import { Component, OnInit } from '@angular/core';
import { Exhibition } from '../exhibition';
import { ParticipantsService } from '../participants.service';

@Component({
  selector: 'app-exhibitionevent',
  templateUrl: './exhibitionevent.component.html',
  styleUrls: ['./exhibitionevent.component.css']
})
export class ExhibitioneventComponent implements OnInit {

  public exhibition : Exhibition = new Exhibition();
  constructor(public participant : ParticipantsService) { }

  ngOnInit(): void {
  }

  public price: number;
  public date: string;

  public getPrice(){
    this.price = (this.exhibition.choice == "Auction")?600:(this.exhibition.choice == "Trade Fair")?800:0;
  }

  public getDate(){
    this.date = (this.exhibition.choice == "Auction")?"15/2/2023":(this.exhibition.choice == "Trade Fair")?"26/1/2023":"";
  }
  public expr:string = "";
  public isValid:boolean = false;
  public validate(): any {
    this.isValid = false;
    if((!this.exhibition.firstName) || (!this.exhibition.lastName))
      this.expr = "Enter full name";
    else
      if(!this.exhibition.email)
        this.expr = "Enter email";
      else
        if((this.exhibition.email.indexOf("@") == -1) || (this.exhibition.email.indexOf(".") == -1))
          this.expr = "Invalid email";
        else
          if((this.exhibition.phone / 1000000000 < 1) || (this.exhibition.phone / 1000000000 >= 10))
            this.expr = "Phone should be 10 digits";
          else
            if(!this.exhibition.choice)
              this.expr = "Choose an event";
            else {
              this.isValid = true;
              this.assign();
              this.expr = "Registration Successful";
            }  
    }

    public assign() {
      this.participant.saveExhibition(this.exhibition)
      .subscribe(data => {
        this.exhibition = data;
      }, error => {
        console.log(error);
      });
  }
}
