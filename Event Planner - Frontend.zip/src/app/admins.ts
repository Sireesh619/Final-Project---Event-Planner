export class Admins {
    id: number;
    name: string;
    password: string;
}
