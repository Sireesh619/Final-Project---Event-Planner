import { Component, OnInit } from '@angular/core';
import { Feedback } from '../feedback';
import { ParticipantsService } from '../participants.service';

@Component({
  selector: 'app-viewfeedbacks',
  templateUrl: './viewfeedbacks.component.html',
  styleUrls: ['./viewfeedbacks.component.css']
})
export class ViewfeedbacksComponent implements OnInit {

  public feedback: Feedback[];
  public id: number;
  constructor(private participant: ParticipantsService) { }

  ngOnInit(): void {
    this.viewAllFeedbacks();
  }

  public viewAllFeedbacks(){
    this.participant.getFeedbackList().subscribe( data => {
      this.feedback = data;
    }, error => {
      console.log(error);
    });
  }

  public deletefeedback(id: number){
    this.participant.deleteFeedback(id).subscribe( data => {
      this.viewAllFeedbacks();
      console.log(data);
    })
  }

}
