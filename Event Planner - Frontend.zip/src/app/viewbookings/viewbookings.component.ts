import { Component, OnInit } from '@angular/core';
import { ParticipantsService } from '../participants.service';
import { Social } from '../social';
import { Corporate } from '../corporate';
import { Exhibition } from '../exhibition';

@Component({
  selector: 'app-viewbookings',
  templateUrl: './viewbookings.component.html',
  styleUrls: ['./viewbookings.component.css']
})
export class ViewbookingsComponent implements OnInit {

  public social : Social[];
  public exhibition : Exhibition[];
  public corporate : Corporate[];
  public option: string;
  public isSocial: boolean = false;
  public isCorporate: boolean = false;
  public isExhibition: boolean = false;

  constructor(private participant: ParticipantsService) { }

  ngOnInit(): void {
  }
  
  public check() {

    this.isSocial = (this.option == "Social")?true:false;
    this.isCorporate = (this.option == "Corporate")?true:false;
    this.isExhibition = (this.option == "Exhibition")?true:false;
    if(this.isSocial){
      this.getSocial();
    }

    if(this.isCorporate){
      this.getCorporate();
    }

    if(this.isExhibition){
      this.getExhibition();
    }
  }
 
  public getSocial(){
    this.participant.getSocialList().subscribe(
      data => {
        this.social = data;
      },
      error => {
        console.log(error);
      }
    )
  }

  public getCorporate(){
    this.participant.getCorporateList().subscribe(
      data => {
        this.corporate = data;
      },
      error => {
        console.log(error);
      }
    )
  }

  public getExhibition(){
    this.participant.getExhibitionList().subscribe(
      data => {
        this.exhibition = data;
      },
      error => {
        console.log(error);
      }
    )
  }
}

