export class Feedback {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    phone: number;
    feedback: string;

}
