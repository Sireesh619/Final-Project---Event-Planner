import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Corporate } from '../corporate';
import { Exhibition } from '../exhibition';
import { ParticipantsService } from '../participants.service';
import { Social } from '../social';

@Component({
  selector: 'app-viewuserbooking',
  templateUrl: './viewuserbooking.component.html',
  styleUrls: ['./viewuserbooking.component.css']
})
export class ViewuserbookingComponent implements OnInit {

  constructor(private paricipant: ParticipantsService, private routes: ActivatedRoute) { }

  public social: Social[];
  public corporate: Corporate[];
  public exhibition: Exhibition[];
  public email: String;

  ngOnInit(): void {
    this.email = this.routes.snapshot.params['email'];
    this.getSocial();
    this.getCorporate();
    this.getExhibition();
  }

  public getSocial(){
    this.paricipant.getSocialbyemail(this.email).subscribe(
      data => {
        this.social = data;
      }, error => console.log(error)
    )
  }

  public getCorporate(){
    this.paricipant.getCorporatebyemail(this.email).subscribe(
      data => {
        this.corporate = data;
      }, error => console.log(error)
    )
  }

  public getExhibition(){
    this.paricipant.getExhibitionbyemail(this.email).subscribe(
      data => {
        this.exhibition = data;
      }, error => console.log(error)
      
    )
  }

}
