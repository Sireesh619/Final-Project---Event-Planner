import { Corporate } from './corporate';

describe('Corporate', () => {
  it('should create an instance', () => {
    expect(new Corporate()).toBeTruthy();
  });
});
