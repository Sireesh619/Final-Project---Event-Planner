import { Component, OnInit } from '@angular/core';
import { ParticipantsService } from '../participants.service';
import { Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-createuser',
  templateUrl: './createuser.component.html',
  styleUrls: ['./createuser.component.css']
})
export class CreateuserComponent implements OnInit {

  public user: User = new User();
  public confirm: string;
  public isValid: boolean = false;
  public expr: string = "";

  constructor(private participant: ParticipantsService, private router: Router) { }

  ngOnInit(): void {
  }

  public validate(){
    this.isValid = false;
    if(!this.user.email){
      this.expr = "Enter email";
    }
    else
      if((this.user.email.indexOf("@") == -1) || (this.user.email.indexOf(".") == -1)){
        this.expr = "Invalid email";
      }
      else
        if(!this.user.password){
          this.expr = "Provide a password";
        }
        else
          if(!this.confirm){
            this.expr = "Confirm password";
          }
          else
            if(this.confirm != this.user.password){
              this.expr = "Passwords must match";
            }
            else{
              this.isValid = true;
              this.saveUser();
              this.expr = "User created";
            }

    }

  public saveUser(){
    this.participant.createUser(this.user).subscribe( data => {
      this.user = data;
      console.log(this.user);
      this.router.navigate(['/view-bookings', this.user.email]);
      }, error => {
        console.log(error);
      })
  }
}
  