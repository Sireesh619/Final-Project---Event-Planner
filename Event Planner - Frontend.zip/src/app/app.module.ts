import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { GalleryComponent } from './gallery/gallery.component';
import { EventComponent } from './event/event.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactComponent } from './contact/contact.component';
import { CorporateeventComponent } from './corporateevent/corporateevent.component';
import { SocialeventComponent } from './socialevent/socialevent.component';
import { ExhibitioneventComponent } from './exhibitionevent/exhibitionevent.component';
import { FormsModule } from '@angular/forms';
import { ParticipantsService } from './participants.service';
import { HttpClientModule } from '@angular/common/http';
import { AdminoptionsComponent } from './adminoptions/adminoptions.component';
import { ViewbookingsComponent } from './viewbookings/viewbookings.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { ViewfeedbacksComponent } from './viewfeedbacks/viewfeedbacks.component';
import { CreateadminComponent } from './createadmin/createadmin.component';
import { CreateuserComponent } from './createuser/createuser.component';
import { ViewuserbookingComponent } from './viewuserbooking/viewuserbooking.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    GalleryComponent,
    EventComponent,
    AboutUsComponent,
    ContactComponent,
    CorporateeventComponent,
    SocialeventComponent,
    ExhibitioneventComponent,
    AdminoptionsComponent,
    ViewbookingsComponent,
    AdminloginComponent,
    ViewfeedbacksComponent,
    CreateadminComponent,
    CreateuserComponent,
    ViewuserbookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ParticipantsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
