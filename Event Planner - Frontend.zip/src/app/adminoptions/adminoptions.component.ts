import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminoptions',
  templateUrl: './adminoptions.component.html',
  styleUrls: ['./adminoptions.component.css']
})
export class AdminoptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
